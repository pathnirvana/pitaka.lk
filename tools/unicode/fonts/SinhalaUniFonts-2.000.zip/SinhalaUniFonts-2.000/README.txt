Sinhala Uni fonts 2.000

Pushpananda Ekanayake's FM and Isi Sinhala designs as Unicode OpenType fonts, released under the
SIL Open Font License 1.1 (OFL.txt): free to use, share and embed, including commercially.

Families: Abhaya Uni, Malithi Uni, Bindumathi Uni, Imanee Uni, Ganganee Uni, Samantha Uni,
Gurulugomi Uni, Arundathee Uni, Alakamanda Uni, Davasa Uni.

INSTALL
  Windows: open the ttf folder, select the fonts, right-click and choose Install.
  macOS: double-click a font and click Install Font (or drag the files into Font Book).
  Linux: copy the files to ~/.local/share/fonts and run fc-cache.

  Abhaya Uni comes two ways: the four static fonts in ttf/ (Regular, Bold, Condensed Regular,
  Condensed Bold) or one variable font in variable/ (weights 400 to 700, and the condensed width).
  Install one or the other, not both: they share the family name. Word and most office software
  work best with the static fonts; design software and websites can use the variable font.

WEB
  webfonts/ has every font as WOFF2. Copy the files to your site and link fonts.css (static fonts)
  or the *-variable.css file (variable font), then use the family name in CSS, for example:
    body { font-family: "Abhaya Uni", serif; }

FILES
  ttf/       MalithiUni-Regular.ttf, AbhayaUni-Regular.ttf, AbhayaUni-Bold.ttf ... (13 fonts)
  variable/  AbhayaUni-Variable.ttf
  webfonts/  the same fonts as WOFF2, with fonts.css and the variable CSS

Authors and upstream projects: AUTHORS.txt.
